﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectivePickupBehavior : MonoBehaviour
{
    public static bool hasBeenAchieved;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
